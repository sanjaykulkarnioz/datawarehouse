import { Server } from "./Server";

const server = new Server();

server.startServer();