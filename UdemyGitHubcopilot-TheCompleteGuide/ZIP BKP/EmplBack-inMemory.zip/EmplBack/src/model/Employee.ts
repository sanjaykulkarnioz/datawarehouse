export type Employee = {
    id: number;
    firstName: string;
    lastName: string;
    hireDate: Date;
    position: string;
}