export type Employee = {
    id: number;
    firstName: string;
    lastName: string;
    hireDate: string;
    position: string;
}