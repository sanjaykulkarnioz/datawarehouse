CREATE TABLE employees (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    last_name VARCHAR(255),
    first_name VARCHAR(255),
    hire_date DATE,
    position VARCHAR(255)
);